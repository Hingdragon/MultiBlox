import ctypes
import msvcrt

ERROR_ALREADY_EXISTS = 183

def activate_multi_instance():
    print("\033[94mWelcome to Roblox Multi-Blox!\n")  # Changed color to blue
    print("\033[94m--- INSTRUCTIONS ---\n 1. Ensure all Roblox instances are closed\n 2. Press any key to activate MultiBlox")  # Changed color to blue
    msvcrt.getch()  # Wait for key press
    print("\n")
    print("\033[91mInitializing MultiBlox...")  # Changed color to red
    mutex = ctypes.windll.kernel32.CreateMutexW(None, True, "ROBLOX_singletonMutex")
    error_code = ctypes.windll.kernel32.GetLastError()
    if mutex == 0 or error_code == ERROR_ALREADY_EXISTS:
        print(f"\033[91mFailed to initiate MultiBlox. Error Code: {error_code}")  # Changed color to red
        return False
    print("\033[0m")  # Reset color to default
    print("Created by Hingdragon\n\n--- Details ---\nYou can now open multiple instances of Roblox, ", end="")
    print("\033[91musing different accounts\033[0m", end="")  # Changed color to red
    print(". Ensure Roblox is completely closed before proceeding or this won't work.\n")
    print("\033[94mRoblox Multi-Instance is now available enjoy grinding!\n")  # Changed color to blue
    print("\033[91mPlease keep this window open.")  # Changed color to red
    msvcrt.getch()  # Wait for another key press
    return True

if __name__ == "__main__":
    activate_multi_instance()
